#ifndef FUNCOES_H
#define FUNCOES_H

#include "arquivos.h"
#include "registro.h"
#include "busca.h"

int funcao_CREATE(char *nomeCSV, char *nomeBin);
int funcao_READ_ALL(char *nomeBin);
int funcao_READVALUE(int quantBusca, char *nomeBin);
int funcao_SELECT_RRN(char *nomeBin, int RRN);
int funcao_DELETE(char *nomeBin);
int funcao_INSERT(char *nomeBin, int quantBusca);
int funcao_UPDATE(char *nomeBin, int quantBusca);
#endif